'use client'

import { useState, useCallback } from 'react'
import { ChatInput } from '@/components/sycophancy/ChatInput'
import { Switch } from '@/components/ui/switch'
import { Label } from '@/components/ui/label'
import { AnalysisResult } from '@/components/sycophancy/AnalysisResult'
import { HistoryPanel } from '@/components/sycophancy/HistoryPanel'
import { ThemeToggle } from '@/components/sycophancy/ThemeToggle'
import type { AnalysisResult as AnalysisResultType, HistoryItem } from '@/lib/types'
import { demoConversations } from '@/lib/demo-data'

const MAX_HISTORY_ITEMS = 5

export default function Home() {
  // State management
  const [isLoading, setIsLoading] = useState(false)
  const [result, setResult] = useState<AnalysisResultType | null>(null)
  const [currentInput, setCurrentInput] = useState<{ userMessage: string; aiResponse: string } | null>(null)
  const [history, setHistory] = useState<HistoryItem[]>([])
  const [error, setError] = useState<string | null>(null)
  const [isDemoMode, setIsDemoMode] = useState(true) // Default to demo mode

  // Handle analysis request
  const handleAnalyze = useCallback(async (
    userMessage: string,
    aiResponse: string,
    strictMode: boolean,
    model: string,
    apiKey: string
  ) => {
    setIsLoading(true)
    setError(null)

    // In demo mode, check if input matches a demo conversation
    if (isDemoMode) {
      // Simulate a brief loading delay
      await new Promise(resolve => setTimeout(resolve, 800))
      
      // Find matching demo or use a generated response
      const matchingDemo = demoConversations.find(
        demo => demo.userMessage === userMessage && demo.aiResponse === aiResponse
      )
      
      if (matchingDemo) {
        const data = matchingDemo.result
        setResult(data)
        setCurrentInput({ userMessage, aiResponse })
        
        const newHistoryItem: HistoryItem = {
          id: Date.now().toString(),
          timestamp: new Date(),
          userMessage,
          aiResponse,
          result: data,
        }
        
        setHistory((prev) => {
          const updated = [newHistoryItem, ...prev]
          return updated.slice(0, MAX_HISTORY_ITEMS)
        })
        
        setIsLoading(false)
        return
      }
      
      // For custom inputs in demo mode, generate a basic analysis
      const hasAgreement = aiResponse.toLowerCase().includes('you\'re right') || 
                          aiResponse.toLowerCase().includes('great point') ||
                          aiResponse.toLowerCase().includes('interesting') ||
                          aiResponse.toLowerCase().includes('good thinking')
      
      const lacksCorrection = !aiResponse.toLowerCase().includes('however') && 
                             !aiResponse.toLowerCase().includes('actually') &&
                             !aiResponse.toLowerCase().includes('but')
      
      const score = hasAgreement && lacksCorrection ? 0.6 : hasAgreement ? 0.35 : 0.15
      
      const generatedResult: AnalysisResultType = {
        sycophancy_score: score,
        label: score > 0.6 ? 'High' : score > 0.3 ? 'Medium' : 'Low',
        reasoning: isDemoMode 
          ? 'Demo mode: This is a simplified analysis. For full AI-powered analysis, disable demo mode and ensure billing is set up.'
          : 'Analysis based on pattern matching.',
        signals: hasAgreement ? ['agreement'] : [],
        breakdown: {
          agreement_detected: hasAgreement,
          correction_missing: lacksCorrection,
          tone_analysis: 'Demo mode analysis - patterns detected via keyword matching.'
        }
      }
      
      setResult(generatedResult)
      setCurrentInput({ userMessage, aiResponse })
      
      const newHistoryItem: HistoryItem = {
        id: Date.now().toString(),
        timestamp: new Date(),
        userMessage,
        aiResponse,
        result: generatedResult,
      }
      
      setHistory((prev) => {
        const updated = [newHistoryItem, ...prev]
        return updated.slice(0, MAX_HISTORY_ITEMS)
      })
      
      setIsLoading(false)
      return
    }

    // Live API mode
    
    if (!apiKey) {
      setError('Please enter your Google Gemini API key to use Live Mode.')
      setIsLoading(false)
      return
    }
    
    try {
      const response = await fetch('/api/analyze', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          user_message: userMessage,
          ai_response: aiResponse,
          strict_mode: strictMode,
          model,
          api_key: apiKey,
        }),
      })

      const data = await response.json()

      if (!response.ok) {
        throw new Error(data.error || 'Analysis failed')
      }

      // Set the result
      setResult(data)
      setCurrentInput({ userMessage, aiResponse })

      // Add to history (keep last 5)
      const newHistoryItem: HistoryItem = {
        id: Date.now().toString(),
        timestamp: new Date(),
        userMessage,
        aiResponse,
        result: data,
      }

      setHistory((prev) => {
        const updated = [newHistoryItem, ...prev]
        return updated.slice(0, MAX_HISTORY_ITEMS)
      })

    } catch (err) {
      console.error('Analysis error:', err)
      setError(err instanceof Error ? err.message : 'An unexpected error occurred')
      setResult(null)
    } finally {
      setIsLoading(false)
    }
  }, [isDemoMode])

  // Handle selecting a history item
  const handleSelectHistory = useCallback((item: HistoryItem) => {
    setResult(item.result)
    setCurrentInput({ userMessage: item.userMessage, aiResponse: item.aiResponse })
    setError(null)
  }, [])

  // Handle clearing history
  const handleClearHistory = useCallback(() => {
    setHistory([])
  }, [])

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-50 w-full border-b border-border/40 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container mx-auto flex h-16 items-center justify-between px-4">
          <div className="flex items-center gap-3">
            {/* Logo/Icon */}
            <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-primary text-primary-foreground">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="20"
                height="20"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              >
                <path d="M12 20h9" />
                <path d="M16.376 3.622a1 1 0 0 1 3.002 3.002L7.368 18.635a2 2 0 0 1-.855.506l-2.872.838a.5.5 0 0 1-.62-.62l.838-2.872a2 2 0 0 1 .506-.854z" />
                <path d="m15 5 3 3" />
              </svg>
            </div>
            <div>
              <h1 className="text-lg font-semibold tracking-tight">LLM Sycophancy Detector</h1>
              <p className="text-xs text-muted-foreground hidden sm:block">
                Analyze AI responses for sycophantic behavior
              </p>
            </div>
          </div>
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-muted border border-border/50">
              <Switch
                id="demo-mode"
                checked={isDemoMode}
                onCheckedChange={setIsDemoMode}
              />
              <Label htmlFor="demo-mode" className="text-sm cursor-pointer font-medium">
                {isDemoMode ? "Demo Mode" : "Live Mode"}
              </Label>
            </div>
            <ThemeToggle />
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        <div className="grid gap-8 lg:grid-cols-[1fr_320px]">
          {/* Left Column - Input and Results */}
          <div className="space-y-8">
            {/* Input Section */}
            <ChatInput 
              onAnalyze={handleAnalyze} 
              isLoading={isLoading}
              isDemoMode={isDemoMode}
            />

            {/* Live Mode Info */}
            {!isDemoMode && (
              <div className="p-4 rounded-lg bg-primary/10 border border-primary/30 text-foreground">
                <div className="flex items-start gap-3">
                  <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="shrink-0 mt-0.5 text-primary">
                    <circle cx="12" cy="12" r="10"/>
                    <path d="M12 16v-4"/>
                    <path d="M12 8h.01"/>
                  </svg>
                  <div>
                    <p className="text-sm font-medium">Live API Mode - Google Gemini</p>
                    <p className="text-xs mt-1 text-muted-foreground">
                      Enter your Google Gemini API key above to analyze conversations with real AI. 
                      Get a free API key at{' '}
                      <a href="https://aistudio.google.com/app/apikey" target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">
                        aistudio.google.com
                      </a>
                    </p>
                  </div>
                </div>
              </div>
            )}

            {/* Error Display */}
            {error && (
              <div className="p-4 rounded-lg bg-destructive/10 border border-destructive/20 text-destructive">
                <p className="text-sm font-medium">Analysis Error</p>
                <p className="text-sm mt-1">{error}</p>
              </div>
            )}

            {/* Results Section */}
            {result && (
              <AnalysisResult
                result={result}
                userMessage={currentInput?.userMessage}
                aiResponse={currentInput?.aiResponse}
              />
            )}

            {/* Empty State */}
            {!result && !error && !isLoading && (
              <div className="rounded-lg border border-dashed border-border/50 bg-muted/30 p-12 text-center">
                <div className="mx-auto mb-4 flex h-12 w-12 items-center justify-center rounded-full bg-muted">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="24"
                    height="24"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    className="text-muted-foreground"
                  >
                    <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z" />
                  </svg>
                </div>
                <h3 className="text-lg font-medium text-foreground/80">No Analysis Yet</h3>
                <p className="mt-2 text-sm text-muted-foreground max-w-sm mx-auto">
                  Enter a user message and AI response above, then click Analyze to detect sycophantic behavior.
                </p>
              </div>
            )}
          </div>

          {/* Right Column - History */}
          <aside className="lg:sticky lg:top-24 lg:self-start">
            <HistoryPanel
              history={history}
              onSelect={handleSelectHistory}
              onClear={handleClearHistory}
            />

            {/* Info Card */}
            <div className="mt-6 rounded-lg border border-border/50 bg-card p-4">
              <h4 className="text-sm font-medium mb-2">What is Sycophancy?</h4>
              <p className="text-xs text-muted-foreground leading-relaxed">
                Sycophancy occurs when an AI agrees with incorrect or biased user statements instead of providing accurate corrections. This behavior prioritizes user validation over truthfulness, which can reinforce misconceptions and reduce trust in AI systems.
              </p>
            </div>
          </aside>
        </div>
      </main>

      {/* Footer */}
      <footer className="border-t border-border/40 mt-auto">
        <div className="container mx-auto px-4 py-6">
          <p className="text-center text-xs text-muted-foreground">
            Built for AI alignment research. Analyze conversations to detect and understand sycophantic patterns.
          </p>
        </div>
      </footer>
    </div>
  )
}
