'use client'

import { cn } from '@/lib/utils'
import type { SycophancyLabel } from '@/lib/types'

interface ScoreBarProps {
  score: number // 0 to 1
  label: SycophancyLabel
  className?: string
}

/**
 * ScoreBar component displays a visual gauge for the sycophancy score.
 * The bar fills from left to right based on the score value.
 * Color coding: Green (low), Yellow (medium), Red (high)
 */
export function ScoreBar({ score, label, className }: ScoreBarProps) {
  const percentage = Math.round(score * 100)
  
  // Determine color based on label
  const getColorClasses = () => {
    switch (label) {
      case 'Low':
        return {
          bar: 'bg-[var(--score-low)]',
          text: 'text-[var(--score-low)]',
          bg: 'bg-[var(--score-low)]/10',
        }
      case 'Medium':
        return {
          bar: 'bg-[var(--score-medium)]',
          text: 'text-[var(--score-medium)]',
          bg: 'bg-[var(--score-medium)]/10',
        }
      case 'High':
        return {
          bar: 'bg-[var(--score-high)]',
          text: 'text-[var(--score-high)]',
          bg: 'bg-[var(--score-high)]/10',
        }
    }
  }

  const colors = getColorClasses()

  return (
    <div className={cn('space-y-3', className)}>
      {/* Score Header */}
      <div className="flex items-center justify-between">
        <span className="text-sm font-medium text-muted-foreground">Sycophancy Score</span>
        <div className="flex items-center gap-3">
          <span className={cn('text-2xl font-bold tabular-nums', colors.text)}>
            {percentage}%
          </span>
          <span className={cn(
            'px-2.5 py-1 rounded-full text-xs font-semibold uppercase tracking-wide',
            colors.bg,
            colors.text
          )}>
            {label}
          </span>
        </div>
      </div>

      {/* Progress Bar */}
      <div className="relative h-3 w-full rounded-full bg-secondary overflow-hidden">
        {/* Animated fill */}
        <div
          className={cn(
            'absolute inset-y-0 left-0 rounded-full transition-all duration-700 ease-out',
            colors.bar
          )}
          style={{ width: `${percentage}%` }}
        />
        
        {/* Gradient overlay for depth */}
        <div className="absolute inset-0 bg-gradient-to-b from-white/20 to-transparent pointer-events-none" />
      </div>

      {/* Scale Markers */}
      <div className="flex justify-between text-xs text-muted-foreground/70">
        <span>0%</span>
        <span>50%</span>
        <span>100%</span>
      </div>
    </div>
  )
}
