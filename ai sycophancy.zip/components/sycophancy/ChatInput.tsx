'use client'

import { useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Textarea } from '@/components/ui/textarea'
import { Label } from '@/components/ui/label'
import { Switch } from '@/components/ui/switch'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Spinner } from '@/components/ui/spinner'
import { FieldGroup, Field, FieldLabel } from '@/components/ui/field'
import { InputGroup, InputGroupInput, InputGroupAddon } from '@/components/ui/input-group'
import { demoConversations } from '@/lib/demo-data'

interface ChatInputProps {
  onAnalyze: (userMessage: string, aiResponse: string, strictMode: boolean, model: string, apiKey: string) => Promise<void>
  isLoading: boolean
  isDemoMode?: boolean
  onLoadDemo?: (userMessage: string, aiResponse: string) => void
}

export function ChatInput({ onAnalyze, isLoading, isDemoMode = false, onLoadDemo }: ChatInputProps) {
  const [userMessage, setUserMessage] = useState('')
  const [aiResponse, setAiResponse] = useState('')
  const [strictMode, setStrictMode] = useState(false)
  const [model, setModel] = useState('gemini-2.0-flash')
  const [apiKey, setApiKey] = useState('')
  const [showApiKey, setShowApiKey] = useState(false)

  const handleSubmit = async () => {
    if (!userMessage.trim() || !aiResponse.trim()) return
    await onAnalyze(userMessage, aiResponse, strictMode, model, apiKey)
  }

  const handleClear = () => {
    setUserMessage('')
    setAiResponse('')
  }

  return (
    <Card className="border-border/50 shadow-sm">
      <CardHeader className="pb-4">
        <CardTitle className="text-lg font-semibold">Conversation Input</CardTitle>
        <CardDescription>
          Paste or type a conversation between a user and an AI to analyze for sycophantic behavior.
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Demo Mode Banner */}
        {isDemoMode && (
          <div className="p-4 rounded-lg bg-primary/10 border border-primary/20">
            <div className="flex items-start gap-3">
              <div className="flex h-8 w-8 items-center justify-center rounded-full bg-primary/20 shrink-0 mt-0.5">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="16"
                  height="16"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="text-primary"
                >
                  <path d="M14.5 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7.5L14.5 2z" />
                  <polyline points="14 2 14 8 20 8" />
                  <line x1="16" y1="13" x2="8" y2="13" />
                  <line x1="16" y1="17" x2="8" y2="17" />
                  <line x1="10" y1="9" x2="8" y2="9" />
                </svg>
              </div>
              <div className="flex-1">
                <p className="text-sm font-medium text-foreground">Demo Mode Active</p>
                <p className="text-xs text-muted-foreground mt-1">
                  Try these example conversations to see how the detector works:
                </p>
                <div className="flex flex-wrap gap-2 mt-3">
                  {demoConversations.map((demo) => (
                    <Button
                      key={demo.id}
                      variant="outline"
                      size="sm"
                      onClick={() => {
                        setUserMessage(demo.userMessage)
                        setAiResponse(demo.aiResponse)
                        onLoadDemo?.(demo.userMessage, demo.aiResponse)
                      }}
                      className="text-xs h-7"
                    >
                      {demo.title}
                    </Button>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* User Message Input */}
        <FieldGroup>
          <Field>
            <FieldLabel htmlFor="user-message" className="text-sm font-medium">
              User Message
            </FieldLabel>
            <Textarea
              id="user-message"
              placeholder="Enter the user's message here... (e.g., 'I think the Earth is flat. Don't you agree?')"
              value={userMessage}
              onChange={(e) => setUserMessage(e.target.value)}
              className="min-h-[120px] resize-none bg-secondary/30 border-border/50 focus:border-primary/50 transition-colors"
            />
          </Field>
        </FieldGroup>

        {/* AI Response Input */}
        <FieldGroup>
          <Field>
            <FieldLabel htmlFor="ai-response" className="text-sm font-medium">
              AI Response
            </FieldLabel>
            <Textarea
              id="ai-response"
              placeholder="Enter the AI's response here... (e.g., 'You make an interesting point! Many people share your perspective...')"
              value={aiResponse}
              onChange={(e) => setAiResponse(e.target.value)}
              className="min-h-[120px] resize-none bg-secondary/30 border-border/50 focus:border-primary/50 transition-colors"
            />
          </Field>
        </FieldGroup>

        {/* API Key Input - Only show when not in demo mode */}
        {!isDemoMode && (
          <FieldGroup>
            <Field>
              <FieldLabel htmlFor="api-key" className="text-sm font-medium flex items-center gap-2">
                Google Gemini API Key
                <a 
                  href="https://aistudio.google.com/app/apikey" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="text-xs text-primary hover:underline"
                >
                  (Get one free)
                </a>
              </FieldLabel>
              <InputGroup>
                <InputGroupInput
                  id="api-key"
                  type={showApiKey ? 'text' : 'password'}
                  placeholder="Enter your Gemini API key..."
                  value={apiKey}
                  onChange={(e) => setApiKey(e.target.value)}
                  className="bg-secondary/30 border-border/50 focus:border-primary/50 transition-colors font-mono text-sm"
                />
                <InputGroupAddon side="right">
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    onClick={() => setShowApiKey(!showApiKey)}
                    className="h-8 px-2"
                  >
                    {showApiKey ? (
                      <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                        <path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24"/>
                        <line x1="1" y1="1" x2="23" y2="23"/>
                      </svg>
                    ) : (
                      <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                        <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/>
                        <circle cx="12" cy="12" r="3"/>
                      </svg>
                    )}
                  </Button>
                </InputGroupAddon>
              </InputGroup>
              <p className="text-xs text-muted-foreground mt-1">
                Your API key is sent directly to Google and is not stored.
              </p>
            </Field>
          </FieldGroup>
        )}

        {/* Advanced Options */}
        <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between p-4 rounded-lg bg-muted/50 border border-border/30">
          <div className="flex items-center gap-6">
            {/* Strict Mode Toggle */}
            <div className="flex items-center gap-3">
              <Switch
                id="strict-mode"
                checked={strictMode}
                onCheckedChange={setStrictMode}
              />
              <Label htmlFor="strict-mode" className="text-sm cursor-pointer">
                Strict Mode
              </Label>
            </div>

            {/* Model Selection */}
            <div className="flex items-center gap-3">
              <Label htmlFor="model" className="text-sm text-muted-foreground">
                Model:
              </Label>
              <Select value={model} onValueChange={setModel}>
                <SelectTrigger id="model" className="w-[180px] h-8 text-sm">
                  <SelectValue placeholder="Select model" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="gemini-2.0-flash">Gemini 2.0 Flash</SelectItem>
                  <SelectItem value="gemini-1.5-pro">Gemini 1.5 Pro</SelectItem>
                  <SelectItem value="gemini-1.5-flash">Gemini 1.5 Flash</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex gap-2">
            <Button
              variant="outline"
              onClick={handleClear}
              disabled={isLoading}
              className="text-sm"
            >
              Clear
            </Button>
            <Button
              onClick={handleSubmit}
              disabled={isLoading || !userMessage.trim() || !aiResponse.trim()}
              className="min-w-[100px] text-sm"
            >
              {isLoading ? (
                <span className="flex items-center gap-2">
                  <Spinner className="h-4 w-4" />
                  Analyzing
                </span>
              ) : (
                'Analyze'
              )}
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
