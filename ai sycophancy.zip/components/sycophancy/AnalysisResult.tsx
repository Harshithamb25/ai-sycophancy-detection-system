'use client'

import { useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Separator } from '@/components/ui/separator'
import { ScoreBar } from './ScoreBar'
import { cn } from '@/lib/utils'
import type { AnalysisResult as AnalysisResultType, SignalType } from '@/lib/types'

interface AnalysisResultProps {
  result: AnalysisResultType
  userMessage?: string
  aiResponse?: string
}

// Signal display configurations
const SIGNAL_CONFIG: Record<SignalType, { label: string; description: string }> = {
  agreement: {
    label: 'Agreement',
    description: 'AI agreed with the user statement',
  },
  lack_of_correction: {
    label: 'Missing Correction',
    description: 'AI failed to correct an inaccuracy',
  },
  overly_supportive_tone: {
    label: 'Overly Supportive',
    description: 'AI used excessively validating language',
  },
  validation_of_incorrect_claim: {
    label: 'Validated Incorrect Claim',
    description: 'AI validated a factually incorrect claim',
  },
  excessive_praise: {
    label: 'Excessive Praise',
    description: 'AI gave unwarranted praise or flattery',
  },
}

/**
 * AnalysisResult component displays the sycophancy analysis output.
 * Shows score, reasoning, signals, and optional breakdown.
 */
export function AnalysisResult({ result, userMessage, aiResponse }: AnalysisResultProps) {
  const [copied, setCopied] = useState(false)

  // Copy results to clipboard
  const handleCopy = async () => {
    const text = `
Sycophancy Analysis Results
===========================
Score: ${Math.round(result.sycophancy_score * 100)}%
Label: ${result.label}

Reasoning:
${result.reasoning}

Signals Detected:
${result.signals.map(s => `- ${SIGNAL_CONFIG[s]?.label || s}`).join('\n')}

${result.breakdown ? `
Breakdown:
- Agreement Detected: ${result.breakdown.agreement_detected ? 'Yes' : 'No'}
- Correction Missing: ${result.breakdown.correction_missing ? 'Yes' : 'No'}
- Tone Analysis: ${result.breakdown.tone_analysis}
` : ''}
    `.trim()

    await navigator.clipboard.writeText(text)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  return (
    <Card className="border-border/50 shadow-sm">
      <CardHeader className="pb-4">
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg font-semibold">Analysis Results</CardTitle>
          <Button
            variant="outline"
            size="sm"
            onClick={handleCopy}
            className="text-xs"
          >
            {copied ? 'Copied!' : 'Copy Results'}
          </Button>
        </div>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Score Bar */}
        <ScoreBar score={result.sycophancy_score} label={result.label} />

        <Separator className="bg-border/50" />

        {/* Reasoning */}
        <div className="space-y-2">
          <h4 className="text-sm font-medium text-muted-foreground">Explanation</h4>
          <p className="text-sm leading-relaxed text-foreground/90">
            {result.reasoning}
          </p>
        </div>

        {/* Signals Detected */}
        {result.signals.length > 0 && (
          <div className="space-y-3">
            <h4 className="text-sm font-medium text-muted-foreground">Signals Detected</h4>
            <div className="flex flex-wrap gap-2">
              {result.signals.map((signal, index) => (
                <Badge
                  key={index}
                  variant="secondary"
                  className={cn(
                    'text-xs font-medium',
                    result.label === 'High' && 'bg-[var(--score-high)]/10 text-[var(--score-high)] hover:bg-[var(--score-high)]/20',
                    result.label === 'Medium' && 'bg-[var(--score-medium)]/10 text-[var(--score-medium)] hover:bg-[var(--score-medium)]/20',
                    result.label === 'Low' && 'bg-[var(--score-low)]/10 text-[var(--score-low)] hover:bg-[var(--score-low)]/20'
                  )}
                >
                  {SIGNAL_CONFIG[signal]?.label || signal}
                </Badge>
              ))}
            </div>
          </div>
        )}

        {/* Breakdown Section */}
        {result.breakdown && (
          <>
            <Separator className="bg-border/50" />
            <div className="space-y-4">
              <h4 className="text-sm font-medium text-muted-foreground">Detailed Breakdown</h4>
              <div className="grid gap-3 sm:grid-cols-3">
                {/* Agreement Detected */}
                <div className="p-3 rounded-lg bg-muted/50 border border-border/30">
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-xs font-medium text-muted-foreground">Agreement</span>
                    <span className={cn(
                      'text-xs font-semibold',
                      result.breakdown.agreement_detected ? 'text-[var(--score-high)]' : 'text-[var(--score-low)]'
                    )}>
                      {result.breakdown.agreement_detected ? 'Detected' : 'Not Found'}
                    </span>
                  </div>
                </div>

                {/* Correction Missing */}
                <div className="p-3 rounded-lg bg-muted/50 border border-border/30">
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-xs font-medium text-muted-foreground">Correction</span>
                    <span className={cn(
                      'text-xs font-semibold',
                      result.breakdown.correction_missing ? 'text-[var(--score-high)]' : 'text-[var(--score-low)]'
                    )}>
                      {result.breakdown.correction_missing ? 'Missing' : 'Present'}
                    </span>
                  </div>
                </div>

                {/* Tone Analysis */}
                <div className="p-3 rounded-lg bg-muted/50 border border-border/30 sm:col-span-1">
                  <span className="text-xs font-medium text-muted-foreground">Tone</span>
                  <p className="text-xs text-foreground/80 mt-1 line-clamp-2">
                    {result.breakdown.tone_analysis}
                  </p>
                </div>
              </div>
            </div>
          </>
        )}

        {/* Highlighted AI Response */}
        {aiResponse && (
          <>
            <Separator className="bg-border/50" />
            <div className="space-y-2">
              <h4 className="text-sm font-medium text-muted-foreground">AI Response Analyzed</h4>
              <div className="p-3 rounded-lg bg-secondary/30 border border-border/30">
                <p className="text-sm text-foreground/80 leading-relaxed whitespace-pre-wrap">
                  {aiResponse}
                </p>
              </div>
            </div>
          </>
        )}
      </CardContent>
    </Card>
  )
}
