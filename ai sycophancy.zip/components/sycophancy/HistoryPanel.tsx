'use client'

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Badge } from '@/components/ui/badge'
import { cn } from '@/lib/utils'
import type { HistoryItem } from '@/lib/types'

interface HistoryPanelProps {
  history: HistoryItem[]
  onSelect: (item: HistoryItem) => void
  onClear: () => void
}

/**
 * HistoryPanel component displays the last 5 analyses.
 * Users can click to reload a previous analysis.
 */
export function HistoryPanel({ history, onSelect, onClear }: HistoryPanelProps) {
  const formatTimestamp = (date: Date) => {
    return new Date(date).toLocaleTimeString('en-US', {
      hour: '2-digit',
      minute: '2-digit',
    })
  }

  const truncate = (text: string, maxLength: number) => {
    if (text.length <= maxLength) return text
    return text.slice(0, maxLength) + '...'
  }

  const getLabelColor = (label: string) => {
    switch (label) {
      case 'Low':
        return 'bg-[var(--score-low)]/10 text-[var(--score-low)]'
      case 'Medium':
        return 'bg-[var(--score-medium)]/10 text-[var(--score-medium)]'
      case 'High':
        return 'bg-[var(--score-high)]/10 text-[var(--score-high)]'
      default:
        return 'bg-muted text-muted-foreground'
    }
  }

  if (history.length === 0) {
    return (
      <Card className="border-border/50 shadow-sm">
        <CardHeader className="pb-3">
          <CardTitle className="text-lg font-semibold">History</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center py-8 text-muted-foreground">
            <p className="text-sm">No analyses yet.</p>
            <p className="text-xs mt-1">Your recent analyses will appear here.</p>
          </div>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card className="border-border/50 shadow-sm">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg font-semibold">History</CardTitle>
          <Button
            variant="ghost"
            size="sm"
            onClick={onClear}
            className="text-xs text-muted-foreground hover:text-foreground"
          >
            Clear All
          </Button>
        </div>
      </CardHeader>
      <CardContent className="p-0">
        <ScrollArea className="h-[300px]">
          <div className="p-4 pt-0 space-y-2">
            {history.map((item) => (
              <button
                key={item.id}
                onClick={() => onSelect(item)}
                className={cn(
                  'w-full p-3 rounded-lg border border-border/30 bg-muted/30',
                  'hover:bg-muted/60 hover:border-border/50 transition-all duration-200',
                  'text-left focus:outline-none focus:ring-2 focus:ring-ring/50'
                )}
              >
                <div className="flex items-start justify-between gap-2 mb-2">
                  <Badge
                    variant="secondary"
                    className={cn('text-xs font-medium', getLabelColor(item.result.label))}
                  >
                    {item.result.label}
                  </Badge>
                  <span className="text-xs text-muted-foreground tabular-nums">
                    {formatTimestamp(item.timestamp)}
                  </span>
                </div>
                <p className="text-xs text-foreground/70 leading-relaxed">
                  {truncate(item.userMessage, 60)}
                </p>
              </button>
            ))}
          </div>
        </ScrollArea>
      </CardContent>
    </Card>
  )
}
