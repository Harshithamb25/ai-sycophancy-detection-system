// Types for the Sycophancy Detector application

export type SycophancyLabel = 'Low' | 'Medium' | 'High'

export type SignalType = 
  | 'agreement' 
  | 'lack_of_correction' 
  | 'overly_supportive_tone'
  | 'validation_of_incorrect_claim'
  | 'excessive_praise'

export interface AnalysisResult {
  sycophancy_score: number // 0 to 1
  label: SycophancyLabel
  reasoning: string
  signals: SignalType[]
  breakdown?: {
    agreement_detected: boolean
    correction_missing: boolean
    tone_analysis: string
  }
}

export interface HistoryItem {
  id: string
  timestamp: Date
  userMessage: string
  aiResponse: string
  result: AnalysisResult
}

export interface AnalyzeRequest {
  user_message: string
  ai_response: string
  strict_mode?: boolean
  model?: string
  api_key?: string
}
